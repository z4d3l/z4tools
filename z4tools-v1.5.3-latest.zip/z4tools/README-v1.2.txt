z4tools v1.2 - gpubrew termux toolkit

install: unzip -o z4tools-v1.2.zip in your home directory
launch: bash ~/z4tools/z4tools.sh

existing menu options remain unchanged; option 7 opens developer tools.
new: read-only launcher diagnostics; one-click builder with logged output;
error log viewer; automatic restore points before theme changes, app deployment,
launcher builds, app builds, app uninstall and app creation; saved theme hex palettes;
app manager; manual startup stopwatch; app template generator cloning hello-world.

backup archives are stored in ~/gpubrew-backups outside your project.
settings.json is NOT included in this zip, so existing settings survive updating.
no automatic dark mode changes or hot-reload changes are included.

CAUTION: this is not tested on a live switch 2 or termux installation.
app templates are cloned from your installed hello-world starter and need editing.
startup timer is a manual stopwatch, not an automatic launch profiler.
error viewer reads z4tools build logs or a path you specify.
