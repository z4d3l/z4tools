z4tools v1.4 developer preview

adds a "hot-reload launcher" entry in the theme editor and main menu.
this entry currently performs READ-ONLY preflight checks. it DOES NOT reload the
switch launcher. do not confuse it with a working hot reload implementation.

all existing z4tools v1.3 features are retained. installation does not change
your GPUBrewLauncher source, shader files, or crimson theme.

next engineering milestone: integrate a safe request listener in launcher-loop.cjs,
create replacement shader pipelines in the host, rebuild command buffers, and
verify a fallback to existing pipelines if the update fails. test on a separate
project copy before applying to a working switch session.
