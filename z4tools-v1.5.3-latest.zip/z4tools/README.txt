z4tools v1.16 (rename from zadiel-tools v1.15)
z4tools — gpubrew launcher toolkit

install (termux):
  cd ~
  unzip -o ~/storage/downloads/z4tools-v1.16.zip
  bash ~/z4tools/z4tools.sh

features:
1 theme maker: edits the actual gpubrew theme source in ~/GPUBrewLauncher and optionally rebuilds. it does not enable automatic dark mode.
2 app deployer: scans ~/storage/downloads/app_deployment/*.zip; prompts before overwriting an app, builds installed apps, and moves completed zips into deployed_zips.
3 backup: saves timestamped full project archives under ~/gpubrew-backups.
4 list backups.
5 restore: requires explicit RESTORE confirmation and moves the current project aside first. stop gpubrew/start.sh before restoring.

notes:
- requires termux with python3, bash, unzip, and the existing gpubrew build environment.
- do not run restore while gpubrew is running.
- original crimson colors remain unchanged unless you use theme maker and confirm applying a new color.
- no hot reload features are included.

new in v1.1:
- ascii art banner in main menu.
- settings option (6) to change/reset app deployment directory.
- deployment directory automatically created on toolkit launch and when deploying.
- settings saved to z4tools/settings.json; deployed_zips follows the chosen directory.
- default deployment directory: ~/storage/downloads/app_deployment
- if Android storage permission is missing, run termux-setup-storage first.

NEW IN v1.15:
- theme maker: choose 0, back, or exit to return to main menu.
- theme maker: invalid inputs retry; blank custom hex cancels.
- app deployer and backup creation/listing have 0-to-back submenus.
- restore: blank path returns to main menu.
- settings already supports 0-to-back.

rename notes:
- new folder ~/z4tools and command bash ~/z4tools/z4tools.sh
- automatically imports deployment directory setting from ~/zadiel-tools/settings.json on first launch.
- old ~/zadiel-tools directory is left untouched.
