z4tools v1.3 - gpubrewlauncher termux toolkit

install: unzip -o ~/storage/downloads/z4tools-v1.3.zip -d ~
run: bash ~/z4tools/z4tools.sh

menu organization:
1 theme maker includes advanced per-asset color choices and theme settings
2 app deployer + app manager includes app icon/name/description and deployment directory settings
3 backups/restore with settings in the submenu
4 launcher builder + diagnostics with settings in submenu
5 logs + startup timer with settings in submenu
6 app template generator
7 install/repair watermark

watermark: 'z4tools' is rendered below 'NiftyFork V1.0.0' using a small generated text-atlas label.
this tool reasserts its attribution when changing source files through its managed operations.
this is not tamperproof: a person editing shader source manually can remove it.
no launcher changes happen merely by installing the toolkit. choose option 7 to install watermark,
or use a managed modification that adds it automatically. rebuild the launcher to display it.

all managed gpubrew modifications require confirmation and a restore point. a restore
point preserves your current crimson sources before edits. do not enable auto dark mode.
advanced colors are limited to known safe anchors. unsupported shader revisions fail closed.

app icons: supply an existing png file path, e.g. ~/storage/downloads/icon.png.
metadata edits may require rebuilding app/catalog and refreshing the switch app list.

this toolkit was tested for syntax and against the supplied original github source;
it has NOT been tested on an actual switch 2/termux device. make a separate manual backup
before first use, and do not edit files while the launcher is building/running.
